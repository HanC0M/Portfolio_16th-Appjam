﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectOnOffManager : MonoBehaviour {
    [SerializeField] private GameObject[] gameObjectsArray;
    [SerializeField] private float interval;
    private void Start()
    {
        //StartCoroutine(CreateObject());
    }

    private GameObject GetDisablePipe() // 비활성화 상태의 파이프를 return
    {

        GameObject result = null;
        foreach (var i in gameObjectsArray)
        {
            if (i.activeSelf == false)
            {//activeSelf => 자기자신의 활성화를 체크함
               result = i;
               break;
            }
        }
        return result;
    }

    private IEnumerator CreateObject()
    {
        while (true)
        {
            GameObject pobj = GetDisablePipe();
            pobj.transform.position = new Vector2(0, 0);
            pobj.SetActive(true);
            yield return new WaitForSeconds(interval);//interval 변수 값 만큼 대기 
        }
    }
}
