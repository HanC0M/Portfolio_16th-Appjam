﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class MyUIElement : MonoBehaviour
{
    private Image myImage;

    private List<Image> childImages = new List<Image>();
    private List<Text> childText = new List<Text>();

    public enum DoType { Fade, ScaleX, ScaleY, Scale, MoveX, MoveY, Move };
    public DoType[] doType;
    public float[] during;
    public Ease[] doShowEase;
    public Ease[] doHideEase;
    public float showWaitTime;
    public float hideWaitTime;

    [Space(20)]

    //if MoveX or MoveY or Move
    public Vector2 hidePos;
    public Vector2 showPos;
    public float fadeAlpha;


    public virtual void Awake()
    {
        for (int i = 0; i < doType.Length; i++)
        {
            if (doType[i] == DoType.Fade)
            {
                childImages.Clear();
                Image im = null;
                for (int ii = 0; ii < transform.childCount; ii++)
                {
                    im = transform.GetChild(ii).GetComponent<Image>();
                    if (im != null)
                    {
                        childImages.Add(im);
                    }
                    im = null;
                }

                childText.Clear();
                Text tx = null;
                for (int ii = 0; ii < transform.childCount; ii++)
                {
                    tx = transform.GetChild(ii).GetComponent<Text>();
                    if (tx != null)
                    {
                        childText.Add(tx);
                    }
                    tx = null;
                }

                break;
            }
        }


        myImage = GetComponent<Image>();
        //myImage.rectTransform = GetComponent<RectTransform>();
    }

    public virtual void Show()
    {
        myImage.DOKill();
        myImage.rectTransform.DOKill();
        for (int ii = 0; ii < childImages.Count; ii++)
        {
            childImages[ii].DOKill();
        }
        for (int ii = 0; ii < childText.Count; ii++)
        {
            childText[ii].DOKill();
        }
        StopAllCoroutines();
        StartCoroutine(ShowCo());

    }

    IEnumerator ShowCo()
    {
        yield return new WaitForSecondsRealtime(showWaitTime);
        for (int i = 0; i < doType.Length; i++)
        {
            switch (doType[i])
            {
                case DoType.Fade:
                    myImage.DOFade(fadeAlpha, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    for (int ii = 0; ii < childImages.Count; ii++)
                    {
                        childImages[ii].DOFade(fadeAlpha, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    }
                    for (int ii = 0; ii < childText.Count; ii++)
                    {
                        childText[ii].DOFade(fadeAlpha, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    }
                    break;
                case DoType.ScaleX:
                    myImage.rectTransform.DOScaleX(1, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    break;
                case DoType.ScaleY:
                    myImage.rectTransform.DOScaleY(1, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    break;
                case DoType.Scale:
                    myImage.rectTransform.DOScale(1, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    break;
                case DoType.MoveX:
                    myImage.rectTransform.DOAnchorPosX(showPos.x, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    break;
                case DoType.MoveY:
                    myImage.rectTransform.DOAnchorPosY(showPos.y, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    break;
                case DoType.Move:
                    myImage.rectTransform.DOAnchorPos(showPos, during[i]).SetEase(doShowEase[i]).SetUpdate(true);
                    break;
                default:
                    break;
            }
        }
    }

    public virtual void Hide()
    {
        myImage.DOKill();
        myImage.rectTransform.DOKill();
        for (int ii = 0; ii < childImages.Count; ii++)
        {
            childImages[ii].DOKill();
        }
        for (int ii = 0; ii < childText.Count; ii++)
        {
            childText[ii].DOKill();
        }
        StopAllCoroutines();
        StartCoroutine(HideCo());

    }

    IEnumerator HideCo()
    {
        yield return new WaitForSecondsRealtime(hideWaitTime);
        for (int i = 0; i < doType.Length; i++)
        {
            switch (doType[i])
            {
                case DoType.Fade:
                    myImage.DOFade(0, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    for (int ii = 0; ii < childImages.Count; ii++)
                    {
                        childImages[ii].DOFade(0, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    }
                    for (int ii = 0; ii < childText.Count; ii++)
                    {
                        childText[ii].DOFade(0, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    }
                    break;
                case DoType.ScaleX:
                    myImage.rectTransform.DOScaleX(0, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    break;
                case DoType.ScaleY:
                    myImage.rectTransform.DOScaleY(0, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    break;
                case DoType.Scale:
                    myImage.rectTransform.DOScale(0, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    break;
                case DoType.MoveX:
                    myImage.rectTransform.DOAnchorPosX(hidePos.x, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    break;
                case DoType.MoveY:
                    myImage.rectTransform.DOAnchorPosY(hidePos.y, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    break;
                case DoType.Move:
                    myImage.rectTransform.DOAnchorPos(hidePos, during[i]).SetEase(doHideEase[i]).SetUpdate(true);
                    break;
                default:
                    break;
            }
        }
    }

    public virtual void Init()
    {
        StopAllCoroutines();
        myImage.DOKill();
        myImage.rectTransform.DOKill();
        for (int ii = 0; ii < childImages.Count; ii++)
        {
            childImages[ii].DOKill();
        }
        for (int ii = 0; ii < childText.Count; ii++)
        {
            childText[ii].DOKill();
        }

        for (int i = 0; i < doType.Length; i++)
        {
            switch (doType[i])
            {
                case DoType.Fade:
                    myImage.DOFade(0, 0);
                    for (int ii = 0; ii < childImages.Count; ii++)
                    {
                        childImages[ii].DOFade(0, 0);
                    }
                    for (int ii = 0; ii < childText.Count; ii++)
                    {
                        childText[ii].DOFade(0, 0);
                    }
                    break;
                case DoType.ScaleX:
                    myImage.rectTransform.DOScaleX(0, 0);
                    break;
                case DoType.ScaleY:
                    myImage.rectTransform.DOScaleY(0, 0);
                    break;
                case DoType.Scale:
                    myImage.rectTransform.DOScale(0, 0);
                    break;
                case DoType.MoveX:
                    myImage.rectTransform.DOAnchorPosX(hidePos.x, 0);
                    break;
                case DoType.MoveY:
                    myImage.rectTransform.DOAnchorPosY(hidePos.y, 0);
                    break;
                case DoType.Move:
                    myImage.rectTransform.DOAnchorPos(hidePos, 0);
                    break;
                default:
                    break;
            }
        }
    }
}
