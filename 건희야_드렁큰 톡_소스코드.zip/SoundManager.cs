﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{

    public static SoundManager instance = null;

    [System.Serializable]
    public class SoundClass
    {
        public SoundTag whatTag;
        public AudioClip clip;
        public float orgVoluem;
    }

    public SoundClass[] allSound;
    public enum SoundTag { Sound_1up, Sound_avoid, Sound_bgm_ingame, Sound_jump};
    public AudioSource loopSource;
    public AudioSource onecSource;

    public float volume_all;
    public float volume_music;
    public float volume_fx;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }

    }

    public SoundClass SoundFineWithTag(SoundTag thisTag)
    {
        for (int i = 0; i < allSound.Length; i++)
        {
            if (allSound[i].whatTag == thisTag)
            {
                return allSound[i];
            }
        }

        return null;
    }

    public void AudioPlay_Loop(SoundTag thisTag)
    {
        loopSource.Stop();
        SoundClass cc = SoundFineWithTag(thisTag);
        loopSource.clip = cc.clip;
        loopSource.volume = volume_all * volume_music * cc.orgVoluem;
        loopSource.Play();
    }


    public void AudioPlay_Once(SoundTag thisTag)
    {
        onecSource.Stop();
        SoundClass cc = SoundFineWithTag(thisTag);
        onecSource.clip = cc.clip;
        onecSource.volume = volume_all * volume_fx * cc.orgVoluem;
        onecSource.Play();
    }


    public void SetVolume_all(float what)
    {
        volume_all = what;
    }

    public void SetVolume_music(float what)
    {
        volume_music = what;
    }

    public void SetVolume_fx(float what)
    {
        volume_fx = what;
    }

}