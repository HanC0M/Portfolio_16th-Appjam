﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {


    public Vector3 orgPos;

    public Vector3 plusVec;
    public float plusFloat;

    public float shake_Turm;
    public float timeGo;

    void Start () {
        orgPos = transform.position;
        timeGo = 0;
        plusFloat = 0;
        plusVec = Vector3.zero;
    }
	
	void Update ()
    {
        transform.position = orgPos + plusVec;
        if (plusFloat != 0)
        {
            plusFloat = plusFloat * 0.8f;

            plusVec = new Vector3(Random.Range(-plusFloat, plusFloat), Random.Range(-plusFloat, plusFloat), 0);

            if (plusFloat < 0.005f)
            {
                plusVec = Vector3.zero;
                plusFloat = 0;
            }
        }

        /*if (plusFloat != 0)
        {
            if (timeGo >= shake_Turm)
            {
                timeGo = 0;

               

                plusFloat = plusFloat * 0.8f;

                plusVec = new Vector3(Random.Range(-plusFloat, plusFloat), Random.Range(-plusFloat, plusFloat), 0);

                if (plusFloat < 0.005f)
                {
                    plusVec = Vector3.zero;
                    plusFloat = 0;
                }

            }
            else
            {
                timeGo += Time.unscaledDeltaTime;
            }
        }*/
    }
}
