﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GangMinManager : MonoBehaviour {


    public static GangMinManager instance = null;

    public bool imsi_TalkPlease;
    [Space(20)]
    public Text[] selectButtons_texts;
    [Space(10)]
    public CanvasScript startCanvas;
    public CanvasScript gameCanvas;
    public CanvasScript talkCanvas;
    public CanvasScript keypadCanvas_JumpAvoid;
    public CanvasScript keypadCanvas_Answering;
    public CanvasScript pauseCanvas;
    public CanvasScript endCanvas;
    public Text endScoreText;
    public Image iconImage;
    public Sprite sp_gibon;
    public Sprite sp_good;
    public Sprite sp_sad;
    [Space(10)]
    public Text tx_ScoreFull;
    public EnergyBar bar_HealthBar;

    public Transform spawnPoint;
    public Transform spawnRandom_Min;
    public Transform spawnRandom_Max;
    public Transform spawndObjectsParent;
    public GameObject[] prf_Obstacle_NeedJumps;
    public GameObject[] prf_Obstacle_NeedAvoids;
    public GameObject[] randomSpawns;
    public Vector2 randomSpawnTime_SUL_Vec;
    public Vector2 randomSpawnTime_GUCK_Vec;

    public EnergyBar bar_TimerBar;

    public Text tx_otherTalkText;
    public MyUIElement unPaused_321Count;
    public Text tx_321Count;

    [Space(40)]
    public float answerTimer_TimerTime;
    public float scorePlusSpeed_Run;
    public float healthMinusSpeed_Run;
    public Vector3 obstaclesSpeedVec;
    public List<Transform> obstacles = new List<Transform>();
    [Space(10)]
    public float answer_minusHp_NotAnswered;
    public float answer_minusHp_BadAnswered;
    public float answer_minusHp_SosoAnswered;
    public float answer_minusHp_GoodAnswered;
    public float speedUpAmount;
    public float speedUpDuring;
    [Space(20)]
    public PlayerScript player;
    public CameraScript cameraScript;
    public TextManager textManager;
    public TextManager.TalkClass nowTalk;
    public GameObject prf_UpParticle;
    public GameObject prf_DownParticle;
    [SerializeField] private int score_Full;
    [SerializeField] private int score_Answer;
    [SerializeField] private int score_Run;
    [SerializeField] private float health;
    public bool isGame_ing;
    public bool isPaused;
    public float aimGameTimeScale;
    public bool isTalking;
    private int talkedCount;

    public int Score_Run
    {
        get
        {
            return score_Run;
        }

        set
        {
            score_Run = value;
            Score_Full = Score_Run + Score_Answer;
        }
    }

    public int Score_Answer
    {
        get
        {
            return score_Answer;
        }

        set
        {
            score_Answer = value;
            Score_Full = Score_Run + Score_Answer;
        }
    }

    public int Score_Full
    {
        get
        {
            return score_Full;
        }

        set
        {
            score_Full = value;
            tx_ScoreFull.text = score_Full.ToString().PadLeft(7, '0');
        }
    }

    public float Health
    {
        get
        {
            return health;
        }

        set
        {
            health = value;
            bar_HealthBar.valueCurrent = Mathf.RoundToInt(health * 4);
            if (health < 0)
                health = 0;
            if(health == 0)
            {
                GameOver();
            }
        }
    }

    private void Awake()
    {
        if(instance == null)
        {
            instance = this;
        } else if(instance != this)
        {
            Destroy(gameObject);
        }

        
    }

    private void Start()
    {
        isGame_ing = false;
        aimGameTimeScale = 1;
        unPaused_321Count.Init();
        GameStart();
        talkedCount = 0;
        //startCanvas.ShowCanvas();
    }

    public void GameStart()
    {
        gameCanvas.ShowCanvas();
        startCanvas.HideCanvas();
        keypadCanvas_JumpAvoid.ShowCanvas();

        Score_Run = 0;
        Score_Answer = 0;
        Health = 130;
        isGame_ing = true;
        isPaused = false;
        aimGameTimeScale = 1;
        Time.timeScale = aimGameTimeScale;
        isTalking = false;
        talkedCount = 0;
        obstacles.Clear();

        iconImage.sprite = sp_gibon;

        StartCoroutine(ObstacleSpawnCoroutine());
        StartCoroutine(RandomSpawn_SUL_Coroutine());
        StartCoroutine(RandomSpawn_GUCK_Coroutine());
        StartCoroutine(Talking_Coroutine());
    }


    private void Update()
    {
        if(isGame_ing && !isPaused)
        {
            Score_Run += Mathf.RoundToInt(scorePlusSpeed_Run * Time.deltaTime);
            Health -= healthMinusSpeed_Run * Time.deltaTime;
            for (int i = 0; i < obstacles.Count; i++)
            {
                if (i >= obstacles.Count)
                {
                    break;
                }

                obstacles[i].transform.position += obstaclesSpeedVec * Time.deltaTime;
                if (obstacles[i].transform.position.x < -7)
                {
                    Destroy(obstacles[i].gameObject);
                    obstacles.RemoveAt(i);
                    i--;
                }
            }
        }
        

        if (imsi_TalkPlease)
        {
            imsi_TalkPlease = false;
            if(talkedCount >= textManager.allTalks.Count)
            {
                talkedCount = 0;
            }
            TalkGetted(textManager.allTalks[talkedCount]);
            talkedCount++;
        }
    }




    IEnumerator ObstacleSpawnCoroutine()
    {
        float rann;
        while (true)
        {
            rann = Random.Range(1, 3f);
            yield return new WaitForSeconds(rann);
            if (!isTalking)
            {
                Debug.Log("Spawn");
                if (Random.Range(0, 2) == 0)
                {
                    int rannnn = Random.Range(0, prf_Obstacle_NeedJumps.Length);
                    obstacles.Add(Instantiate(prf_Obstacle_NeedJumps[rannnn], new Vector3(spawnPoint.position.x, prf_Obstacle_NeedJumps[rannnn].transform.position.y, prf_Obstacle_NeedJumps[rannnn].transform.position.z), Quaternion.identity, spawndObjectsParent).transform);

                }
                else
                {
                    int rannnn = Random.Range(0, prf_Obstacle_NeedAvoids.Length);
                    obstacles.Add(Instantiate(prf_Obstacle_NeedAvoids[rannnn], new Vector3(spawnPoint.position.x, prf_Obstacle_NeedAvoids[rannnn].transform.position.y, prf_Obstacle_NeedAvoids[rannnn].transform.position.z), Quaternion.identity, spawndObjectsParent).transform);
                }
            }
                
        }
    }

    IEnumerator RandomSpawn_SUL_Coroutine()
    {
        float rann;
        yield return new WaitForSeconds(15);
        while (true)
        {
            rann = Random.Range(randomSpawnTime_SUL_Vec.x, randomSpawnTime_SUL_Vec.y);
            yield return new WaitForSeconds(rann);
            if(!isTalking)
                obstacles.Add(Instantiate(randomSpawns[0], new Vector3(spawnRandom_Min.position.x, Random.Range(spawnRandom_Min.position.y, spawnRandom_Max.position.y), spawnRandom_Min.position.z), Quaternion.identity, spawndObjectsParent).transform);
        }
    }

    IEnumerator RandomSpawn_GUCK_Coroutine()
    {
        float rann;
        yield return new WaitForSeconds(25);
        while (true)
        {
            rann = Random.Range(randomSpawnTime_GUCK_Vec.x, randomSpawnTime_GUCK_Vec.y);
            yield return new WaitForSeconds(rann);
            if (!isTalking)
                obstacles.Add(Instantiate(randomSpawns[1], new Vector3(spawnRandom_Min.position.x, Random.Range(spawnRandom_Min.position.y, spawnRandom_Max.position.y), spawnRandom_Min.position.z), Quaternion.identity, spawndObjectsParent).transform);
        }
    }

    IEnumerator Talking_Coroutine()
    {
        yield return new WaitForSeconds(12);
        while (true)
        {
            isTalking = true;
            yield return new WaitForSeconds(2);
            if (talkedCount >= textManager.allTalks.Count)
            {
                talkedCount = 0;
            }
            TalkGetted(textManager.allTalks[talkedCount]);
            talkedCount++;
            if (Time.timeScale > 1)
                Time.timeScale = 1;
            yield return new WaitForSeconds(4);
            isTalking = false;
            yield return new WaitForSeconds(9);

        }
    }


    public void TalkGetted(TextManager.TalkClass gettedTalk)
    {
        nowTalk = gettedTalk;


        List<string> saves_MyTalks = new List<string>();
        saves_MyTalks.Clear();
        List<string> saves_appropriateLevels = new List<string>();
        saves_appropriateLevels.Clear();
        for(int i = 0; i < nowTalk.myTalks.Length; i++)
        {
            saves_MyTalks.Add(nowTalk.myTalks[i]);
            saves_appropriateLevels.Add(nowTalk.appropriateLevel[i]);
        }

        for(int i = 0; i < nowTalk.myTalks.Length; i++)
        {
            int ra = Random.Range(0, saves_MyTalks.Count);
            nowTalk.myTalks[i] = saves_MyTalks[ra];
            nowTalk.appropriateLevel[i] = saves_appropriateLevels[ra];
            saves_MyTalks.RemoveAt(ra);
            saves_appropriateLevels.RemoveAt(ra);
        }


        isTalking = true;
        if (AnswerTimer_coco != null)
        {
            StopCoroutine(AnswerTimer_coco);
        }
        AnswerTimer_coco = StartCoroutine(AnswerTimer());
        talkCanvas.ShowCanvas();
        KeypadCanvasChange_ToAnswering();

        tx_otherTalkText.text = nowTalk.othersTalk;

        for (int i = 0; i < selectButtons_texts.Length; i++)
        {
            selectButtons_texts[i].text = nowTalk.myTalks[i];
        }
    }

    private Coroutine AnswerTimer_coco;

    IEnumerator AnswerTimer()
    {
        for(float passed = 0; passed < answerTimer_TimerTime; passed += Time.deltaTime)
        {
            bar_TimerBar.valueCurrent = Mathf.RoundToInt((answerTimer_TimerTime - passed) / answerTimer_TimerTime * 200);
            yield return null;
        }

        TimeOut();
        talkCanvas.HideCanvas();
        KeypadCanvasChange_ToJumpAvoid();
        isTalking = false;
    }

    public void AnswerChoiced(int what)
    {
        switch (nowTalk.appropriateLevel[what])
        {
            case "Good":
                Health -= answer_minusHp_GoodAnswered;
                Instantiate_Particle_Up();
                Score_Answer += 2500;
                iconImage.sprite = sp_good;
                StartCoroutine(WaitAndGibonnn());
                break;

            case "Soso":
                Health -= answer_minusHp_SosoAnswered;
                Score_Answer += 1000;
                break;

            case "Bad":
                Health -= answer_minusHp_BadAnswered;
                Instantiate_Particle_Down();
                iconImage.sprite = sp_sad;
                StartCoroutine(WaitAndGibonnn());
                break;

            default:
                break;
        }

        talkCanvas.HideCanvas();
        KeypadCanvasChange_ToJumpAvoid();
        isTalking = false;
    }

    IEnumerator WaitAndGibonnn()
    {
        yield return new WaitForSeconds(3f);
        iconImage.sprite = sp_gibon;
    }


    public void TimeOut()
    {
        Health -= answer_minusHp_NotAnswered;
    }



    public void KeypadCanvasChange_ToAnswering()
    {
        keypadCanvas_JumpAvoid.HideCanvas();
        keypadCanvas_Answering.ShowCanvas();
    }

    public void KeypadCanvasChange_ToJumpAvoid()
    {
        keypadCanvas_JumpAvoid.ShowCanvas();
        keypadCanvas_Answering.HideCanvas();
    }


    public void GamePause()
    {
        if(UnPause_coco != null)
        {
            StopCoroutine(UnPause_coco);
        }

        isPaused = true;
        Time.timeScale = 0;
        pauseCanvas.ShowCanvas();
    }

    public void GameUnPause()
    {
        unPaused_321Count.Show();

        if (UnPause_coco != null)
        {
            StopCoroutine(UnPause_coco);
        }
        UnPause_coco = StartCoroutine(UnPauseCo());
        pauseCanvas.HideCanvas();
    }

    private Coroutine UnPause_coco;

    IEnumerator UnPauseCo()
    {
        float aa = 0.5f;
        tx_321Count.text = 3 + "";
        yield return new WaitForSecondsRealtime(aa);
        tx_321Count.text = 2 + "";
        yield return new WaitForSecondsRealtime(aa);
        tx_321Count.text = 1 + "";
        yield return new WaitForSecondsRealtime(aa);
        tx_321Count.text = "Go!";
        unPaused_321Count.Hide();
        Time.timeScale = aimGameTimeScale;
        isPaused = false;
    }




    public void SpeedUp()
    {
        aimGameTimeScale = speedUpAmount;
        Time.timeScale = aimGameTimeScale;

        if(waitAndTimeScaleNormal_coco != null)
        {
            StopCoroutine(waitAndTimeScaleNormal_coco);
        }
        waitAndTimeScaleNormal_coco = StartCoroutine(WaitAndTimeScaleNormal());
    }

    private Coroutine waitAndTimeScaleNormal_coco;

    IEnumerator WaitAndTimeScaleNormal()
    {
        yield return new WaitForSecondsRealtime(speedUpDuring);
        aimGameTimeScale = 1;
        Time.timeScale = aimGameTimeScale;
    }



    public void Instantiate_Particle_Up()
    {
        Destroy(Instantiate(prf_UpParticle, player.transform.position + new Vector3(0, 0.6f, -2), prf_UpParticle.transform.rotation), 2);
    }
    public void Instantiate_Particle_Down()
    {
        Destroy(Instantiate(prf_DownParticle, player.transform.position + new Vector3(0, 0.6f, -2), prf_DownParticle.transform.rotation), 2);
    }


    public void GameOver()
    {
        if(isGame_ing == true)
        {
            isGame_ing = false;
            Debug.Log("Game Over 게임오버 ㅅㅅㅅㅅㅅㅅ");

            StopAllCoroutines();
            player.Dieee();

            endCanvas.ShowCanvas();
            endScoreText.text = Score_Full.ToString().PadLeft(7, '0');

            SoundManager.instance.loopSource.Stop();
        }
        
    }

    public void ToMain()
    {
        SceneManager.LoadScene(0);
    }

    public void Restart()
    {
        SceneManager.LoadScene(1);
    }

}
