﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MyUIButton : MyUIElement
{

    private Button myButton;

    public override void Awake()
    {
        base.Awake();
        myButton = GetComponent<Button>();
    }

    public override void Show()
    {
        base.Show();
        myButton.interactable = true;
    }

    public override void Hide()
    {
        base.Hide();
        myButton.interactable = false;
    }

    public override void Init()
    {
        base.Init();
        myButton.interactable = false;
    }


}
