﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bar_ : MonoBehaviour {
    Transform transform;
	// Use this for initialization
	void Start () {
        transform = gameObject.GetComponent<Transform>();
	}
	
	// Update is called once per frame
	void Update () {
        if(GangMinManager.instance.isGame_ing)
            transform.Translate(new Vector3(0.6f * Time.deltaTime,0.0f,0.0f));
        if (transform.position.x < -7)
        {
            Destroy(gameObject);
        }
	}
}
