﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class CanvasScript : MonoBehaviour
{

    [HideInInspector] public bool isShow;
    public float waitShowTime;
    public float autoDisabledTime;

    public MyUIElement[] elements;

    [Space(10)]

    [HideInInspector] public Canvas myCanvas;

    public bool hideeee;
    public bool showwww;

    private void Update()
    {
        if (hideeee)
        {
            hideeee = false;
            HideCanvas();
        }

        if (showwww)
        {
            showwww = false;
            ShowCanvas();
        }
    }

    public virtual void Start()
    {
        myCanvas = GetComponent<Canvas>();
        InitCanvas();
        isShow = false;
    }

    public virtual void InitCanvas()
    {
        for (int i = 0; i < elements.Length; i++)
        {
            elements[i].Init();
        }
        myCanvas.enabled = false;
    }

    public virtual void ShowCanvas()
    {
        isShow = true;
        StopAllCoroutines();
        StartCoroutine(WaitAndShow());
    }

    IEnumerator WaitAndShow()
    {
        yield return new WaitForSecondsRealtime(waitShowTime);
        for (int i = 0; i < elements.Length; i++)
        {
            elements[i].Show();
        }
        myCanvas.enabled = true;
    }

    public virtual void HideCanvas()
    {
        isShow = false;
        StopAllCoroutines();
        for (int i = 0; i < elements.Length; i++)
        {
            elements[i].Hide();
        }
        StartCoroutine(WaitAndDisable());
    }

    IEnumerator WaitAndDisable()
    {
        yield return new WaitForSecondsRealtime(autoDisabledTime);
        myCanvas.enabled = false;
    }
}