﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

public class MyLoopElement : MonoBehaviour {


    public enum DoType { Fade, ScaleX, ScaleY, Scale, MoveX, MoveY, Move };
    public DoType[] doType;
    public int[] loopCount;
    public float[] loopDuring;
    public Ease[] loopEase;
    public LoopType[] loopType;
    public Vector2[] loopAmount;

    private RectTransform myRect;


    private void Awake()
    {
        myRect = GetComponent<RectTransform>();
    }
    void Start ()
    {
		
	}

    public void LoopStart()
    {
        myRect.DOKill();


        for (int i = 0; i < doType.Length; i++)
        {
            switch (doType[i])
            {
                case DoType.Fade:
                    myRect.GetComponent<Image>().DOFade(1, loopDuring[i]).SetEase(loopEase[i]).SetLoops(loopCount[i], loopType[i]);
                    break;
                case DoType.ScaleX:
                    myRect.localScale = new Vector3(1 - (loopAmount[i].x * 0.5f), 1, 1);
                    myRect.DOScaleX(myRect.localScale.x + loopAmount[i].x, loopDuring[i]).SetEase(loopEase[i]).SetLoops(loopCount[i], loopType[i]);
                    break;
                case DoType.ScaleY:
                    myRect.localScale = new Vector3(1, 1 - (loopAmount[i].y * 0.5f), 1);
                    myRect.DOScaleY(myRect.localScale.y + loopAmount[i].y, loopDuring[i]).SetEase(loopEase[i]).SetLoops(loopCount[i], loopType[i]);
                    break;
                case DoType.Scale:
                    myRect.localScale = new Vector3(1 - (loopAmount[i].x * 0.5f), 1 - (loopAmount[i].y * 0.5f), 1);
                    myRect.DOScale(loopAmount[i], loopDuring[i]).SetEase(loopEase[i]).SetLoops(loopCount[i], loopType[i]);
                    break;
                case DoType.MoveX:
                    myRect.anchoredPosition = new Vector2(0 - (loopAmount[i].x * 0.5f),0);
                    myRect.DOAnchorPosX(loopAmount[i].x, loopDuring[i]).SetEase(loopEase[i]).SetLoops(loopCount[i], loopType[i]);
                    break;
                case DoType.MoveY:
                    myRect.anchoredPosition = new Vector2(0, 0 - (loopAmount[i].y * 0.5f));
                    myRect.DOAnchorPosY(loopAmount[i].y, loopDuring[i]).SetEase(loopEase[i]).SetLoops(loopCount[i], loopType[i]);
                    break;
                case DoType.Move:
                    myRect.anchoredPosition = new Vector2(0 - (loopAmount[i].x * 0.5f), 0 - (loopAmount[i].y * 0.5f));
                    myRect.DOAnchorPos(loopAmount[i], loopDuring[i]).SetEase(loopEase[i]).SetLoops(loopCount[i], loopType[i]);
                    break;
                default:
                    break;
            }
        }
    }

    public void StopLoop()
    {
        myRect.DOKill();
    }
	
}
