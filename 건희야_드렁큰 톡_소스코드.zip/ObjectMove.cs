﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectMove : MonoBehaviour {
    public float Speed;
    // Use this for initialization

    // Update is called once per frame
    void Update()
    {
        if (GangMinManager.instance.isGame_ing)
            gameObject.transform.Translate(-Speed * Time.deltaTime, 0f, 0f);
        if (transform.position.x < -7.0f)
        {
            gameObject.SetActive(false); //체크 박스 해제
        }
    }

}
