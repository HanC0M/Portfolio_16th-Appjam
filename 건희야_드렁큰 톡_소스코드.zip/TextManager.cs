﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextManager : MonoBehaviour {


    public int talkListLength;

    public class TalkClass
    {
        public string othersTalk;
        public string[] myTalks;
        public string[] appropriateLevel;
    }

    public List<TalkClass> allTalks = new List<TalkClass>();

	void Start ()
    {
        /*for (int i = 0; i < talkListLength; i++)
        {
            paths.Add(Application.dataPath + @"\talkList" + i + ".txt");
            allTexts.Add(System.IO.File.ReadAllLines(paths[i]));

            TalkClass newTalk = new TalkClass();

            newTalk.othersTalk = allTexts[i][0];
            newTalk.myTalks = new string[3];
            newTalk.myTalks[0] = allTexts[i][1];
            newTalk.myTalks[1] = allTexts[i][2];
            newTalk.myTalks[2] = allTexts[i][3];
            newTalk.appropriateLevel = new string[3];
            newTalk.appropriateLevel[0] = allTexts[i][4];
            newTalk.appropriateLevel[1] = allTexts[i][5];
            newTalk.appropriateLevel[2] = allTexts[i][6];

            allTalks.Add(newTalk);
        }*/

    }
}
