﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
public class TextCut : MonoBehaviour {

    // Use this for initialization

    string m_strPath;

    public void Start()
    {
        m_strPath = Application.dataPath + @"\talk.txt";
        Parse();
    }


    string[] values;


    public void Parse()
    {
        GangMinManager.instance.textManager.allTalks.Clear();
        string[] source = System.IO.File.ReadAllLines(m_strPath);
        for(int i = 0; i < source.Length; i++)
        {
            values = source[i].Split('/');
            Addddd();
        }

    }

    public void Addddd()
    {
        int i = 0;

        TextManager.TalkClass newTalk = new TextManager.TalkClass();


        newTalk.othersTalk = values[i];
        Debug.Log(values[i]);
        newTalk.myTalks = new string[3];
        i++;
        newTalk.myTalks[0] = values[i];
        Debug.Log(values[i]);
        i++;
        newTalk.myTalks[1] = values[i];
        Debug.Log(values[i]);
        i++;
        newTalk.myTalks[2] = values[i];
        Debug.Log(values[i]);
        newTalk.appropriateLevel = new string[3];
        newTalk.appropriateLevel[0] = "Good";
        newTalk.appropriateLevel[1] = "Soso";
        newTalk.appropriateLevel[2] = "Bad";

        GangMinManager.instance.textManager.allTalks.Add(newTalk);
    }

	// Update is called once per frame
}
