﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class PlayerScript : MonoBehaviour {


    private Animator anim;

    public float jumpSpeed;
    public bool isCanJump;

    public Vector3 gravityPower;

    public float healthMinus_HittedByEnemy_NeedJump;
    public float healthMinus_HittedByEnemy_NeedAvoid;
    public float healthPlus_SUL;
    public float healthPlus_GUCK;

    [Space(20)]

    public Vector3 myNowSpeed;
    public bool avoiding;

	void Start ()
    {
        avoiding = false;
        myNowSpeed = Vector3.zero;
        anim = GetComponent<Animator>();
        AnimOnlyTrueThis("Walking");
        SoundManager.instance.AudioPlay_Loop(SoundManager.SoundTag.Sound_bgm_ingame);
    }
	
	void Update ()
    {

        myNowSpeed += gravityPower* Time.deltaTime;



        if (isCanJump)
        {
            if (Input.GetKey(KeyCode.Space))
            {
                isCanJump = false;
                myNowSpeed = new Vector3(0, jumpSpeed * GangMinManager.instance.aimGameTimeScale, 0);
                AnimOnlyTrueThis("Jumping");
            }
        }

        if (Input.GetKeyDown(KeyCode.A))
        {
            Avoid();
        }

        if (!GangMinManager.instance.isPaused)
        {
            transform.position += myNowSpeed;
        }
        

    }

    public void Avoid()
    {
        transform.parent.DOKill();
        transform.parent.localRotation = Quaternion.identity;
        transform.parent.DOLocalRotate(new Vector3(0, -90, 0), 0.4f).SetEase(Ease.InOutSine).SetLoops(2, LoopType.Yoyo);

        if (avoiding_coco != null)
        {
            StopCoroutine(avoiding_coco);
        }
        avoiding_coco = StartCoroutine(Avoiding_Co());
        SoundManager.instance.AudioPlay_Once(SoundManager.SoundTag.Sound_avoid);
    }

    private Coroutine avoiding_coco;

    IEnumerator Avoiding_Co()
    {
        avoiding = true;
        yield return new WaitForSeconds(0.4f);
        avoiding = false;
    }


    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Ground"))
        {
            isCanJump = true;
            if (GangMinManager.instance.isGame_ing)
            {
                AnimOnlyTrueThis("Walking");
            } else
            {
            }
            
        } 
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy_NeedJump"))
        {
            other.gameObject.GetComponent<BoxCollider>().enabled = false;
            Hitted(healthMinus_HittedByEnemy_NeedJump);

        }
        else if (other.CompareTag("Enemy_NeedAvoid"))
        {
            other.gameObject.GetComponent<BoxCollider>().enabled = false;
            if (avoiding)
            {
                Debug.Log("회피성공!!!!!!!!!! 끼요ㅗㅅ");
            }
            else
            {
                Hitted(healthMinus_HittedByEnemy_NeedAvoid);
            }
        } else if (other.CompareTag("SUL"))
        {
            GangMinManager.instance.obstacles.Remove(other.gameObject.transform);
            Destroy(other.gameObject);
            GangMinManager.instance.Health += healthPlus_SUL;
            GangMinManager.instance.Instantiate_Particle_Up();
            SoundManager.instance.AudioPlay_Once(SoundManager.SoundTag.Sound_1up);
        } else if (other.CompareTag("GUCK"))
        {
            GangMinManager.instance.obstacles.Remove(other.gameObject.transform);
            Destroy(other.gameObject);
            GangMinManager.instance.SpeedUp();
            GangMinManager.instance.Health += healthPlus_GUCK;
            GangMinManager.instance.Instantiate_Particle_Up();
            SoundManager.instance.AudioPlay_Once(SoundManager.SoundTag.Sound_1up);
        }
    }

    private void OnCollisionStay(Collision other)
    {
        if (other.gameObject.CompareTag("Ground"))
        {
            myNowSpeed = Vector3.zero;
        }
    }

    public void Hitted(float healthMinus)
    {
        GangMinManager.instance.Health -= healthMinus;
        GangMinManager.instance.cameraScript.plusFloat = 0.25f;
        GangMinManager.instance.Instantiate_Particle_Down();
    }


    public void JumpPressed()
    {
        if (isCanJump)
        {
            isCanJump = false;
            myNowSpeed = new Vector3(0, jumpSpeed * GangMinManager.instance.aimGameTimeScale, 0);
            AnimOnlyTrueThis("Jumping");
            SoundManager.instance.AudioPlay_Once(SoundManager.SoundTag.Sound_jump);
        }
    }

    public void AvoidPressed()
    {
        Avoid();
    }


    public void Dieee()
    {
        AnimOnlyTrueThis("Die");
    }

    public void AnimOnlyTrueThis(string what)
    {
        anim.SetBool("Walking", false);
        anim.SetBool("Jumping", false);
        anim.SetBool("Die", false);

        anim.SetBool(what, true);
    }
}
